package ApplicationAgent;

public class mainProd {
	public static void main(String[] args) {
		ApplicationAgent appA = new ApplicationAgent();
		appA.connexion();
		appA.menuPrincipal();
		
	}
	
}
